document.getElementById('invertbutton').addEventListener('click',() => {
    console.log("Invert button clicked");
    document.body.classList.toggle('invert-colors')
});
document.getElementById('darkMode').addEventListener('click', () => {
    console.log("Invert button clicked");
    document.body.classList.toggle('dark-mode')
});